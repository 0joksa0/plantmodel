% This script simulates and plots ATHB2 and FT mRNA expression at two 
% temperatures in the WT and the pif4;pif5 mutant in 16L:8D, as shown 
% in Figure 5. This serves as an example of how to simulate the model and 
% compare results across multiple conditions.

addpath('plotting_tools')

% Indices of the species of interest (i.e. ATHB2 mRNA and FT mRNA)
Sidx = [8,15];
nS = length(Sidx);

% Specify the range of conditions (WT at 22oC, pif4;5 at 22oC, WT at 27oC, 
% pif4;5 at 27oC)

% Each photoperiod must take a value between 0 (constant darkness) and 24
% (constant light)
photoperiods = [16,16,16,16];

% Each genotype is a cell array of strings specifying mutants (see
% load_P2011_parameters and load_PIF_CO_FT_parameters functions for details
% of which mutants can be specified for the clock and PIF_CO_FT models,
% respectively).
genotypes = { {''},{'pif4','pif5'},{''},{'pif4','pif5'} };

% Temperature can take a value of either 22 or 27 (the conditions of our
% experiments).
temperatures = [22,22,27,27];

nC = length(genotypes);

linestyles = {'k-','k--','r-','r--'};

figure()
hold on

for i = 1:nC
    
    % set the conditions in this case
    options = struct();
    options.genotype = genotypes{i};
    options.temperature = temperatures(i);
    options.photoperiod = photoperiods(i);
    
    [T,Y] = simulate_model(options);
    
    % plot the results for each species on separate panels
    for j = 1:nS
        subplot(1,2,j)
        hold on
        plot(T,Y(:,Sidx(j)),linestyles{i})
    end
end

% Format plots
species_names = {'ATHB2','FT'};
for j = 1:2
    subplot(1,2,j)
    box on
    xlim([0,24])
    xlabel('Time (ZT Hrs)')
    ylabel('Relative Expression')
    circaplot([],[],[0,16],['w','k'],24)
    v = axis;
    text(v(1)+0.5,v(4)*0.8,species_names{j},'FontAngle','italic')
end

subplot(1,2,2)
legend(['WT, 22{\fontname{symbol}',176,'}C sim'],['{\it{pif4;5}}, 22{\fontname{symbol}',176,'}C sim'],...
    ['WT, 27{\fontname{symbol}',176,'}C sim'],['{\it{pif4;5}}, 27{\fontname{symbol}',176,'}C sim'])
