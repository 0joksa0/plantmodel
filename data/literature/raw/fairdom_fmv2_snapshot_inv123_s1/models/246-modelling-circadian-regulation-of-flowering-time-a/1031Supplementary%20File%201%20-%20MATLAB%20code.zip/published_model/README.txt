*********RUNNING SIMULATIONS*********

The model can be simulated through the function "simulate_model". This 
function takes as input an options structure with four fields: photoperiod, 
temperature, genotype, and Poverride.

* photoperiod - number in the range 0 to 24 specifying the photoperiod.

* temperature - integer taking the value of 22 or 27 (i.e. the two 
temperatures simulated in the paper).

* genotype - cell array of the form { 'genotype1','genotype2',...}. Any 
cell array that does not contain valid genotypes is taken to be the 
wildtype. An array containing the empty string (i.e. {''}) is used to 
denote this in the example simulation scripts. The following is a list 
of valid genotype options:

CLOCK MUTANTS
cca1
CCA1ox
lhy
LHYox
toc1
prr5
prr7
prr9
gi
elf3
lux
ztl

HYPOCOTYL MUTANTS
pif4
PIF4ox
pif5
PIF5ox

FLOWERING MUTANTS
cdf1
CDF1ox
co
COox
cop1
fkf1


* Poverride - struct in which any field with the name of a valid parameter 
will override that parameters value with the value stored in 
"Poverride.parameter_name".

The output is a pair of time and state vectors [T,Y]. The state vector Y 
describes the dynamics of the following components:

Y(1) PIF4m
Y(2) PIF5m
Y(3) PIF
Y(4) phyB
Y(5) PR
Y(6) INT
Y(7) IAA29m
Y(8) ATHB2m
Y(9) CDF1m
Y(10) FKF1m
Y(11) FKF1
Y(12) CDF1
Y(13) COm
Y(14) CO
Y(15) FTm
Y(16) InducedC1
Y(17) InducedC2
Y(18) RepressedC1


*********EXAMPLE*********

By way of example, the following code simulates the model in an fkf1 
mutant in LDs (16L:8D) conditions at 22oC.


options = struct();
options.genotype = {'fkf1'};
options.photoperiod = 16;
options.temperature = 22;

[T,Y] = simulate_model(options);


Additional examples are given in the accompanying 
"CO_FT_in_elf3_simulation_script.m" and 
"temperature_response_simulation_script.m" files.

*********FILE DESCRIPTIONS*********

* simulate_model.m - function that simulates the combined model. Takes as 
input an options struct describing the high-level conditions of 
photoperiod, genotype, and temperature. Outputs time and state vectors 
describing the dynamics of the PIF_CO_FT model.

* light_conditions - function that takes as input the time and an options 
struct describing the light conditions (photoperiod, period, phase) common 
to the whole model (i.e. both the P2011 clock model and PIF_CO_FT models 
use this function), and outputs the light conditions at that time.

* CO_FT_in_elf3_simulation_script.m - simulates and plots CO and FT mRNA 
expression in the elf3  mutant in LDs (16L:8D), as seen in Supplementary 
Figure S7. This serves as an example of how to simulate the model in a 
single condition.

* temperature_response_simulation_script - simulates and plots ATHB2 and 
FT mRNA expression at two temperatures in the WT and the pif4;pif5 mutant 
in 16L:8D, as shown in Figure 5. This serves as an example of how to 
simulate the model and compare results across multiple conditions.

* P2011_model
	* load_P2011_dynamics.m - function that loads parameters for the P2011 
    circadian clock model. Takes as input a cell array describing the 
    plant genotype being simulated, and outputs a vector of parameter 
    values.
	* P2011_dynamics.m - function that evaluates the ODEs describing the 
    dynamics of the P2011 circadian clock model. Takes as input the time, 
    a state vector, and a vector of parameter values, and outputs a vector 
    of time derivatives.
	* wrap_P2011_model.m - function that processes the dynamics of the 
    P2011 clock model into the format required for input to the PIF_CO_FT 
    model.

* PIF_CO_FT_model
	* load_PIF_CO_FT_parameters.m - function that loads parameters for the 
    PIF_CO_FT model. Takes as input a cell array describing the plant 
    genotype being simulated and the temperature, and outputs a struct of 
    parameter values.
	* PIF_CO_FT_dynamics.m - function that evaluates the ODEs describing 
    the dynamics of the PIF_CO_FT model. Takes as input the time, a state 
    vector, a struct of parameter values, and a struct of input dynamics 
    (from the circadian clock). Outputs a vector of time derivatives.
	* PIF_CO_FT_parameters.mat - data file storing the parameter struct 
    loaded by load_PIF_CO_FT_parameters.

* plotting_tools
	* circaplot.m - function to plot light:dark cycles on the x-axis of 
    figures.
	* reorder_timeseries.m - function to reorder a timeseries from a 
    single day to start and finish at a different time.
