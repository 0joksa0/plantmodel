% This script simulates and plots CO and FT mRNA expression in the elf3 
% mutant in LDs (16L:8D), as seen in Supplementary Figure S7. This serves 
% as an example of how to simulate the model in a single condition.

addpath('plotting_tools')

% Indices of the species of interest (i.e. CO mRNA and FT mRNA)
Sidx = [13,15];
nS = length(Sidx);

% set the conditions in this case
options = struct();
options.genotype = {'elf3'}; %elf3 mutant
options.temperature = 22; % temperature (oC)
options.photoperiod = 16; % photoperiod (Hr)

[T,Y] = simulate_model(options);
    
% plot the results for each species on separate panels
for j = 1:nS
    subplot(1,2,j)
    hold on
    plot(T,Y(:,Sidx(j)),'b--')
end

% Format plots
species_names = {'CO','FT'};
for j = 1:2
    subplot(1,2,j)
    box on
    xlim([0,24])
    xlabel('Time (ZT Hrs)')
    ylabel('Relative Expression')
    circaplot([],[],[0,16],['w','k'],24)
    v = axis;
    text(v(1)+0.5,v(4)*0.8,species_names{j},'FontAngle','italic')
end

subplot(1,2,2)
legend('elf3')